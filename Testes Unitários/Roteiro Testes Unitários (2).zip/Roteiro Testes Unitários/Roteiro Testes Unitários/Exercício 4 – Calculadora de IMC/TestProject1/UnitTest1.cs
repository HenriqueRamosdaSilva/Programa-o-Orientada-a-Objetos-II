using Xunit;
using Exerc�cio_4_Calculadora_de_IMC ;

namespace TestProject1
{
    public class CalculadoraIMCTests
    {
        [Fact]
        public void Calcular_DeveRetornarResultadoCorreto()
        {
            var calc = new CalculadoraIMC();

            double resultado = calc.Calcular(70, 1.75);

            Assert.Equal(22.86, resultado, 2);
        }

        [Fact]
        public void Classificar_DeveRetornarAbaixoDoPeso()
        {
            var calc = new CalculadoraIMC();
            string resultado = calc.Classificar(17);
            Assert.Equal("Abaixo do peso", resultado);
        }

        [Fact]
        public void Classificar_DeveRetornarSobrepeso()
        {
            var calc = new CalculadoraIMC();
            string resultado = calc.Classificar(26);
            Assert.Equal("Sobrepeso", resultado);
        }

        [Fact]
        public void Calcular_DeveLancarErro_QuandoAlturaForZero()
        {
            var calc = new CalculadoraIMC();
            Assert.Throws<ArgumentException>(() => calc.Calcular(70, 0));
        }
    }
}