using System;
using Xunit;
using Carrinho_Compras;

namespace Carrinho_Teste
{
    public class UnitTest1
    {
        [Fact]
        public void AdicionarItem_DeveAumentarQuantidade()
        {
            // Arrange
            var carrinho = new Carrinho_Compras.Carrinho();
            var item = new Carrinho_Compras.Item { Nome = "Laranja", Preco = 4.0 };
            // Act
            carrinho.Adicionar(item);
            // Assert
            Assert.Equal(1, carrinho.Quantidade());
        }
        [Fact]
        public void Limpar_DeveZerarQuantidade()
        {
            // Arrange
            var carrinho = new Carrinho_Compras.Carrinho();
            var item = new Carrinho_Compras.Item { Nome = "Uva", Preco = 6.0 };
            carrinho.Adicionar(item);
            // Act
            carrinho.Limpar();
            // Assert
            Assert.Equal(0, carrinho.Quantidade());
        }
        [Fact]
        public void Adicionar_Soma_TotalCorreto()
        {
            // Arrange
            var carrinho = new Carrinho_Compras.Carrinho();
            var item1 = new Carrinho_Compras.Item { Nome = "Pera", Preco = 3.5 };
            var item2 = new Carrinho_Compras.Item { Nome = "Manga", Preco = 7.0 };
            // Act
            carrinho.Adicionar(item1);
            carrinho.Adicionar(item2);
            var total = carrinho.Total();
            // Assert
            Assert.Equal(10.5, total);
        }


    }


}

