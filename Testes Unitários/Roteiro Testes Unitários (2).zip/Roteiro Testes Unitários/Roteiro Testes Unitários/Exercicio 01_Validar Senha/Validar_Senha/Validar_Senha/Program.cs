﻿using System.Text.RegularExpressions;
namespace AulaTestes
{
    public class ValidadorSenha
    {
        public bool EhValida(string senha)
        {
            if (string.IsNullOrEmpty(senha)) return false;
            if (senha.Length < 8) return false;
            bool contemLetra = Regex.IsMatch(senha, "[A-Za-z]");
            bool contemNumero = Regex.IsMatch(senha, "[0-9]");
            return contemLetra && contemNumero;
        }
    }
    public class Program
    {
        public static void Main(string[] args)
        {
            var validador = new ValidadorSenha();
            string senhaParaTestar = "Senha123";
            string senhaParaTestarnumero = "12345678";
            string senhaParaTestarnulo = "";
            string senhaParaTestarletras = "abcdEFGH";
            bool resultado = validador.EhValida(senhaParaTestar);
            bool resultadonumero = validador.EhValida(senhaParaTestarnumero);
            bool resultadonulo = validador.EhValida(senhaParaTestarnulo);
            bool resultadoletras = validador.EhValida(senhaParaTestarletras);

            Console.WriteLine($"A senha '{senhaParaTestar}' é válida? {resultado}");
            Console.WriteLine($"A senha '{senhaParaTestarnumero}' é válida? {resultadonumero}");
            Console.WriteLine($"A senha '{senhaParaTestarnulo}' é válida? {resultadonulo}");
            Console.WriteLine($"A senha '{senhaParaTestarletras}' é válida? {resultadoletras}");

        }
    }
}
