using Xunit;
using Exerc�cio_3___Conversor_de_Temperatura; // Importa o seu projeto principal

namespace TestProject1
{
    public class UnitTest1
    {
        [Fact]
        public void CelsiusParaFahrenheit_DeveRetornar32_QuandoEntradaFor0()
        {
            // Arrange
            var conversor = new ConversorTemperatura();

            // Act
            var resultado = conversor.CelsiusParaFahrenheit(0);

            // Assert
            Assert.Equal(32, resultado, 2);
        }

        [Fact]
        public void CelsiusParaFahrenheit_DeveRetornar212_QuandoEntradaFor100()
        {
            // Arrange
            var conversor = new ConversorTemperatura();

            // Act
            var resultado = conversor.CelsiusParaFahrenheit(100);

            // Assert
            Assert.Equal(212, resultado, 2);
        }

        [Fact]
        public void FahrenheitParaCelsius_DeveRetornarZero_QuandoEntradaFor32()
        {
            // Arrange
            var conversor = new ConversorTemperatura();

            // Act
            var resultado = conversor.FahrenheitParaCelsius(32);

            // Assert
            Assert.Equal(0, resultado, 2);
        }

        [Fact]
        public void FahrenheitParaCelsius_DeveRetornar100_QuandoEntradaFor212()
        {
            // Arrange
            var conversor = new ConversorTemperatura();

            // Act
            var resultado = conversor.FahrenheitParaCelsius(212);

            // Assert
            Assert.Equal(100, resultado, 2);
        }
    }
}