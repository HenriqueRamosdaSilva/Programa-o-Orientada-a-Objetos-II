using System;
using Xunit;


namespace Validar_Senha_Teste
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

            var validador = new AulaTestes.ValidadorSenha();
            bool resultado = validador.EhValida("Senha123");
            Assert.True(resultado);

        }
        [Fact]
        public void Test2()
        {
            var validador = new AulaTestes.ValidadorSenha();
            bool resultado = validador.EhValida("12345678");
            Assert.False(resultado);

        }
        [Fact]
        public void Test3()
        {
            var validador = new AulaTestes.ValidadorSenha();
            bool resultado = validador.EhValida("");
            Assert.False(resultado);
        }
        [Fact]
        public void Test4()
        {

            var validador = new AulaTestes.ValidadorSenha();
            bool resultado = validador.EhValida("abcdEFGH");
            Assert.False(resultado);
        }
    }
}