﻿using System.Collections.Generic;
using System.Linq;
using Carrinho_Compras;
namespace Carrinho_Compras
{
    public class Item
    {
        public string Nome { get; set; }
        public double Preco { get; set; }
    }
    public class Carrinho
    {
        private List<Item> itens = new();
        public void Adicionar(Item item)
        {
            itens.Add(item);
        }
        public double Total()
        {
            return itens.Sum(i => i.Preco);
        }
        public int Quantidade()
        {
            return itens.Count;
        }
        public void Limpar()
        {
            itens.Clear();
        }
    }
}
class Program
{
    static void Main(string[] args)
    {
        var carrinho = new Carrinho();

        carrinho.Adicionar(new Item { Nome = "Maçã", Preco = 2.5 });
        carrinho.Adicionar(new Item { Nome = "Banana", Preco = 3.0 });

        Console.WriteLine($"Quantidade de itens: {carrinho.Quantidade()}");
        Console.WriteLine($"Total: R$ {carrinho.Total():0.00}");

        carrinho.Limpar();
        Console.WriteLine($"Carrinho limpo. Quantidade: {carrinho.Quantidade()}");
    }
}


